// SideMenu.js
import React from 'react';
import './SideMenu.css';
import { Link } from 'react-router-dom';

const SideMenu = ({ isOpen, toggleMenu, handleLogout, isLoggedIn }) => {
    return (
        <div>
            <div className="hamburger" onClick={toggleMenu}>
                <div className="line"></div>
                <div className="line"></div>
                <div className="line"></div>
            </div>
            <div className={`side-menu ${isOpen ? 'open' : ''}`}>
                <ul>
                    <li><Link to="/home" onClick={toggleMenu}>Home</Link></li>
                    <li><Link to="/products" onClick={toggleMenu}>Products</Link></li>
                    <li><Link to="/customers" onClick={toggleMenu}>Customers</Link></li>
                    <li><Link to="/admins" onClick={toggleMenu}>Admins</Link></li>
                    <li><Link to="/about" onClick={toggleMenu}>About</Link></li>
                    <li><Link to="/contact" onClick={toggleMenu}>Contact</Link></li>
                    {isLoggedIn ? (
                        <li><button onClick={() => { handleLogout(); toggleMenu(); }} className="logout-button">Logout</button></li>
                    ) : (
                        <>
                            <li><Link to="/login" onClick={toggleMenu}>Login</Link></li>
                            <li><Link to="/register" onClick={toggleMenu}>Register</Link></li>
                        </>
                    )}
                </ul>
            </div>
        </div>
    );
};

export default SideMenu;
