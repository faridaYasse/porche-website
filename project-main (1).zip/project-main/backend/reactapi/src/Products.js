// Products.js
import React from 'react';
import SideMenu from './SideMenu';
import './PageStyles.css';

const Products = ({ products, addProduct, updateProduct, deleteProduct, isOpen, toggleMenu, handleLogout, isLoggedIn }) => {
    return (
        <div className={`page-container ${isOpen ? 'menu-open' : ''}`}>
            <SideMenu isOpen={isOpen} toggleMenu={toggleMenu} handleLogout={handleLogout} isLoggedIn={isLoggedIn} />
            <div className="content">
                <h2>Products</h2>
                <ul>
                    {products.map(product => (
                        <li key={product._id}>
                            <div className="item-info">
                                <strong>Name:</strong> {product.Product_name}
                            </div>
                            <div className="item-actions">
                                {/* <button onClick={() => updateProduct(product._id, { Product_name: 'Updated Name', description: 'Updated Description' })}>Update</button> */}
                                <button onClick={() => deleteProduct(product._id)}>Delete</button>
                                <button onClick="updateProduct('id', 'updatedProduct')">update</button>
                            </div>
                        </li>
                    ))}
                </ul>
                <button className="add-button" onClick={() => addProduct({ Product_name: 'New Product', description: 'New Description' })}>Add Product</button>
            </div>
        </div>
    );
};

export default Products;
