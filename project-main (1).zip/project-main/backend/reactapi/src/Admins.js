// Admins.js
import React from 'react';
import SideMenu from './SideMenu';
import './PageStyles.css';

const Admins = ({ admins, addAdmin, updateAdmin, deleteAdmin, isOpen, toggleMenu, handleLogout, isLoggedIn }) => {
    return (
        <div className={`page-container ${isOpen ? 'menu-open' : ''}`}>
            <SideMenu isOpen={isOpen} toggleMenu={toggleMenu} handleLogout={handleLogout} isLoggedIn={isLoggedIn} />
            <div className="content">
                <h2>Admins</h2>
                <ul>
                    {admins.map(admin => (
                        <li key={admin._id}>
                            <div className="item-info">
                                <strong>Username:</strong> {admin.username}, <strong>Email:</strong> {admin.email}
                            </div>
                            <div className="item-actions">
                                <button onClick={() => updateAdmin(admin._id, { username: 'updatedUsername', email: 'updated@example.com' })}>Update</button>
                                <button onClick={() => deleteAdmin(admin._id)}>Delete</button>
                            </div>
                        </li>
                    ))}
                </ul>
                <button className="add-button" onClick={() => addAdmin({ username: 'newAdmin', email: 'newadmin@example.com' })}>Add Admin</button>
            </div>
        </div>
    );
};

export default Admins;
