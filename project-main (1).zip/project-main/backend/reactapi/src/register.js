import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './login.css'; // Optional, if you want to reuse some styles

const Register = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate(); // Hook for navigation

    const handleRegister = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://localhost:3000/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            if (response.ok) {
                alert('Registration successful. You can now login.');
                navigate('/login'); // Navigate to login page after successful registration
            } else {
                const data = await response.json();
                alert(data.error);
            }
        } catch (error) {
            console.error('Error registering:', error);
            alert('An error occurred while registering. Please try again.');
        }
    };

    return (
        <div className="login-container">
            <div className="card">
                <div className="card-body">
                    <div className="text-center">
                        <img
                            src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/lotus.webp"
                            alt="logo"
                        />
                        <h4 className="mt-1 mb-5 pb-1">Join Porsche </h4>
                    </div>

                    <form onSubmit={handleRegister}>
                        <p>Create your account</p>

                        <div className="form-outline mb-4">
                            <label className="form-label" htmlFor="form2Example11">Username</label>
                            <input
                                type="text"
                                id="form2Example11"
                                className="form-control"
                                placeholder="Choose a username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                            />
                        </div>

                        <div className="form-outline mb-4">
                            <label className="form-label" htmlFor="form2Example22">Password</label>
                            <input
                                type="password"
                                id="form2Example22"
                                className="form-control"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                            />
                        </div>

                        <div className="text-center pt-1 mb-5 pb-1">
                            <button className="btn btn-primary btn-block" type="submit">Register</button>
                        </div>
                    </form>
                </div>
                <div className="gradient-custom-2">
                    <h4 className="mb-4">We are Porsche</h4>
                    
                </div>
            </div>
        </div>
    );
};

export default Register;
