import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import './App.css';
import Login from './login';
import Register from './register';
import Home from './home';
import Products from './Products';
import Customers from './Customers';
import Admins from './Admins';
import About from './About';
import Contact from './Contact';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            products: [],
            customers: [],
            admins: [],
            pages: {
                index: "",
                login: "",
                register: "",
                contact: "",
                about: ""
            },
            isLoaded: false,
            error: null,
            token: localStorage.getItem('token') || '',
            isMenuOpen: false
        };
    }

    componentDidMount() {
        this.fetchData();
    }

    fetchData = () => {
        const token = this.state.token;
        console.log("Fetching data with token:", token);

        Promise.all([
            fetch('http://localhost:3000/Products', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(res => {
                if (!res.ok) {
                    throw new Error(`Products: ${res.statusText}`);
                }
                return res.json();
            }),

            fetch('http://localhost:3000/Customers', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(res => {
                if (!res.ok) {
                    throw new Error(`Customers: ${res.statusText}`);
                }
                return res.json();
            }),

            fetch('http://localhost:3000/Admins', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(res => {
                if (!res.ok) {
                    throw new Error(`Admins: ${res.statusText}`);
                }
                return res.json();
            })
        ])
        .then(([products, customers, admins]) => {
            console.log("Data fetched successfully");
            this.setState({
                isLoaded: true,
                products,
                customers,
                admins,
                error: null
            });
        })
        .catch(error => {
            this.setState({ error: error.message, isLoaded: true });
            console.error('Error fetching data:', error);
        });
    }

    handleLogin = (token) => {
        console.log("Logging in with token:", token);
        this.setState({ token }, () => {
            localStorage.setItem('token', token);
            console.log("Token stored in local storage:", localStorage.getItem('token'));
            this.fetchData();
        });
    };

    handleLogout = () => {
        this.setState({ token: '' }, () => {
            localStorage.removeItem('token');
            this.setState({
                products: [],
                customers: [],
                admins: [],
                pages: {
                    index: "",
                    login: "",
                    register: "",
                    contact: "",
                    about: ""
                },
                isLoaded: false,
                error: null
            });
        });
    };

    toggleMenu = () => {
        this.setState(prevState => ({
            isMenuOpen: !prevState.isMenuOpen
        }));
    };

    addProduct = async (product) => {
        const token = this.state.token;
        try {
            const response = await fetch('http://localhost:3000/Products', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(product)
            });
            if (response.ok) {
                this.fetchData(); // Refresh product list
            } else {
                const errorData = await response.json();
                console.error('Failed to add product:', errorData);
            }
        } catch (error) {
            console.error('Error adding product:', error);
        }
    };

    updateProduct = async (id, updatedProduct) => {
        const token = this.state.token;
        try {
            const response = await fetch(`http://localhost:3000/Products/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(updatedProduct)
            });
            if (response.ok) {
                this.fetchData(); // Refresh product list
            } else {
                const errorData = await response.json();
                console.error('Failed to update product:', errorData);
            }
        } catch (error) {
            console.error('Error updating product:', error);
        }
    };
    handleUpdateClick = () => {
        const productId = '12345'; // Replace with the actual product ID
        const updatedProduct = {
            name: 'Updated Product Name',
            price: 99.99,
            // Add other updated fields here
        };

        this.updateProduct(productId, updatedProduct);
    }

    deleteProduct = async (id) => {
        const token = this.state.token;
        try {
            const response = await fetch(`http://localhost:3000/Products/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            if (response.ok) {
                this.fetchData(); // Refresh product list
            } else {
                const errorData = await response.json();
                console.error('Failed to delete product:', errorData);
            }
        } catch (error) {
            console.error('Error deleting product:', error);
        }
    };

    addCustomer = async (customer) => {
        const token = this.state.token;
        try {
            const response = await fetch('http://localhost:3000/Customers', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(customer)
            });
            if (response.ok) {
                this.fetchData(); // Refresh customer list
            } else {
                const errorData = await response.json();
                console.error('Failed to add customer:', errorData);
            }
        } catch (error) {
            console.error('Error adding customer:', error);
        }
    };

    updateCustomer = async (id, updatedCustomer) => {
        const token = this.state.token;
        try {
            const response = await fetch(`http://localhost:3000/Customers/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(updatedCustomer)
            });
            if (response.ok) {
                this.fetchData(); // Refresh customer list
            } else {
                const errorData = await response.json();
                console.error('Failed to update customer:', errorData);
            }
        } catch (error) {
            console.error('Error updating customer:', error);
        }
    };

    deleteCustomer = async (id) => {
        const token = this.state.token;
        try {
            const response = await fetch(`http://localhost:3000/Customers/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            if (response.ok) {
                this.fetchData(); // Refresh customer list
            } else {
                const errorData = await response.json();
                console.error('Failed to delete customer:', errorData);
            }
        } catch (error) {
            console.error('Error deleting customer:', error);
        }
    };

    addAdmin = async (admin) => {
        const token = this.state.token;
        try {
            const response = await fetch('http://localhost:3000/Admins', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(admin)
            });
            if (response.ok) {
                this.fetchData(); // Refresh admin list
            } else {
                const errorData = await response.json();
                console.error('Failed to add admin:', errorData);
            }
        } catch (error) {
            console.error('Error adding admin:', error);
        }
    };

    updateAdmin = async (id, updatedAdmin) => {
        const token = this.state.token;
        try {
            const response = await fetch(`http://localhost:3000/Admins/${id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(updatedAdmin)
            });
            if (response.ok) {
                this.fetchData(); // Refresh admin list
            } else {
                const errorData = await response.json();
                console.error('Failed to update admin:', errorData);
            }
        } catch (error) {
            console.error('Error updating admin:', error);
        }
    };

    deleteAdmin = async (id) => {
        const token = this.state.token;
        try {
            const response = await fetch(`http://localhost:3000/Admins/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            if (response.ok) {
                this.fetchData(); // Refresh admin list
            } else {
                const errorData = await response.json();
                console.error('Failed to delete admin:', errorData);
            }
        } catch (error) {
            console.error('Error deleting admin:', error);
        }
    };

    render() {
        const { isLoaded, token, products, customers, admins, error, isMenuOpen } = this.state;
        const isLoggedIn = !!token;

        if (error) {
            console.log(error);
        } 
        if (!isLoaded) {
            return <div className="loading">Loading...</div>;
        } else {
            return (
                <Router>
                    <div className="App">
                        {isLoggedIn ? (
                            <div>
                                <Routes>
                                    <Route path="/home" element={
                                        <Home 
                                            isOpen={isMenuOpen} 
                                            toggleMenu={this.toggleMenu} 
                                            handleLogout={this.handleLogout}
                                            isLoggedIn={isLoggedIn}
                                        />
                                    } />
                                    <Route path="/products" element={
                                        <Products
                                            products={products}
                                            addProduct={this.addProduct}
                                            updateProduct={this.updateProduct}
                                            deleteProduct={this.deleteProduct}
                                            isOpen={isMenuOpen}
                                            toggleMenu={this.toggleMenu}
                                            handleLogout={this.handleLogout}
                                            isLoggedIn={isLoggedIn}
                                        />
                                    } />
                                    <Route path="/customers" element={
                                        <Customers
                                            customers={customers}
                                            addCustomer={this.addCustomer}
                                            updateCustomer={this.updateCustomer}
                                            deleteCustomer={this.deleteCustomer}
                                            isOpen={isMenuOpen}
                                            toggleMenu={this.toggleMenu}
                                            handleLogout={this.handleLogout}
                                            isLoggedIn={isLoggedIn}
                                        />
                                    } />
                                    <Route path="/admins" element={
                                        <Admins
                                            admins={admins}
                                            addAdmin={this.addAdmin}
                                            updateAdmin={this.updateAdmin}
                                            deleteAdmin={this.deleteAdmin}
                                            isOpen={isMenuOpen}
                                            toggleMenu={this.toggleMenu}
                                            handleLogout={this.handleLogout}
                                            isLoggedIn={isLoggedIn}
                                        />
                                    } />
                                    <Route path="/about" element={<About />} />
                                    <Route path="/contact" element={<Contact />} />
                                    <Route path="*" element={<Navigate to="/home" />} />
                                </Routes>
                            </div>
                        ) : (
                            <Routes>
                                <Route path="/login" element={
                                    <div>
                                        <h2>Login</h2>
                                        <Login onLogin={this.handleLogin} />
                                    </div>
                                } />
                                <Route path="/register" element={
                                    <div>
                                        <h2>Register</h2>
                                        <Register />
                                    </div>
                                } />
                                <Route path="*" element={<Navigate to="/login" />} />
                            </Routes>
                        )}
                    </div>
                </Router>
            );
        }
    }
}

export default App;
