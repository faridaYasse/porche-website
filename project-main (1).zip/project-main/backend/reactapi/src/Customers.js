// Customers.js
import React from 'react';
import SideMenu from './SideMenu';
import './PageStyles.css';

const Customers = ({ customers, addCustomer, updateCustomer, deleteCustomer, isOpen, toggleMenu, handleLogout, isLoggedIn }) => {
    return (
        <div className={`page-container ${isOpen ? 'menu-open' : ''}`}>
            <SideMenu isOpen={isOpen} toggleMenu={toggleMenu} handleLogout={handleLogout} isLoggedIn={isLoggedIn} />
            <div className="content">
                <h2>Customers</h2>
                <ul>
                    {customers.map(customer => (
                        <li key={customer._id}>
                            <div className="item-info">
                                <strong>Name:</strong> {customer.name}, <strong>Email:</strong> {customer.email}
                            </div>
                            <div className="item-actions">
                                <button onClick={() => updateCustomer(customer._id, { name: 'Updated Name', email: 'updated@example.com' })}>Update</button>
                                <button onClick={() => deleteCustomer(customer._id)}>Delete</button>
                            </div>
                        </li>
                    ))}
                </ul>
                <button className="add-button" onClick={() => addCustomer({ name: 'New Customer', email: 'new@example.com' })}>Add Customer</button>
            </div>
        </div>
    );
};

export default Customers;
