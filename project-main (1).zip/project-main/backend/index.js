const express = require('express');
const cors = require('cors');
const path = require('path');
const { MongoClient, ServerApiVersion, ObjectId } = require('mongodb');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Set view engine
app.set('view engine', 'ejs');

// Middleware to serve static files from 'public' directory
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// JWT secret key
const JWT_SECRET = process.env.JWT_SECRET;

// Log incoming requests
app.use((req, res, next) => {
    console.log(`Received ${req.method} request for ${req.url}`);
    next();
});

// MongoDB connection
const uri = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PASSWORD}@cluster0.tgzqzqu.mongodb.net`;
const client = new MongoClient(uri, {
    serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
    }
});

const dbName = 'porschecar';

// CRUD operations for Products
async function createProduct(productData) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const productsCollection = db.collection('Products');
        const result = await productsCollection.insertOne(productData);
        console.log('New product added:', result.insertedId);
    } finally {
        // await client.close();
    }
}

async function readProductById(productId) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const productsCollection = db.collection('Products');
        const product = await productsCollection.findOne({ _id: ObjectId(productId) });
        console.log('Product found:', product);
        return product;
    } finally {
        // await client.close();
    }
}

async function updateProduct(productId, updatedData) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const productsCollection = db.collection('Products');
        const result = await productsCollection.updateOne({ _id: ObjectId(productId) }, { $set: updatedData });
        console.log('Product updated:', result.modifiedCount);
    } finally {
        // await client.close();
    }
}

async function deleteProduct(productId) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const productsCollection = db.collection('Products');
        const result = await productsCollection.deleteOne({ _id: ObjectId(productId) });
        console.log('Product deleted:', result.deletedCount);
    } finally {
        // await client.close();
    }
}

async function getAllProducts() {
    try {
        await client.connect();
        const db = client.db(dbName);
        const productsCollection = db.collection('Products');
        const products = await productsCollection.find({}).toArray();
        console.log('All products:', products);
        return products;
    } finally {
        // await client.close();
    }
}

// CRUD operations for Admins
async function createAdmin(adminData) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const adminsCollection = db.collection('Admins');
        const result = await adminsCollection.insertOne(adminData);
        console.log('New admin added:', result.insertedId);
    } finally {
        // await client.close();
    }
}

async function readAdminById(adminId) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const adminsCollection = db.collection('Admins');
        const admin = await adminsCollection.findOne({ _id: ObjectId(adminId) });
        console.log('Admin found:', admin);
        return admin;
    } finally {
        // await client.close();
    }
}

async function updateAdmin(adminId, updatedData) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const adminsCollection = db.collection('Admins');
        const result = await adminsCollection.updateOne({ _id: ObjectId(adminId) }, { $set: updatedData });
        console.log('Admin updated:', result.modifiedCount);
    } finally {
        // await client.close();
    }
}

async function deleteAdmin(adminId) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const adminsCollection = db.collection('Admins');
        const result = await adminsCollection.deleteOne({ _id: ObjectId(adminId) });
        console.log('Admin deleted:', result.deletedCount);
    } finally {
        // await client.close();
    }
}

async function getAllAdmins() {
    try {
        await client.connect();
        const db = client.db(dbName);
        const adminsCollection = db.collection('Admins');
        const admins = await adminsCollection.find({}).toArray();
        console.log('All Admins:', admins);
        return admins;
    } finally {
        // await client.close();
    }
}

// CRUD operations for Customers
async function createCustomer(customerData) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const customersCollection = db.collection('Customers');
        const result = await customersCollection.insertOne(customerData);
        console.log('New customer added:', result.insertedId);
    } finally {
        // await client.close();
    }
}

async function readCustomerById(customerId) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const customersCollection = db.collection('Customers');
        const customer = await customersCollection.findOne({ _id: ObjectId(customerId) });
        console.log('Customer found:', customer);
        return customer;
    } finally {
        // await client.close();
    }
}

async function updateCustomer(customerId, updatedData) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const customersCollection = db.collection('Customers');
        const result = await customersCollection.updateOne({ _id: ObjectId(customerId) }, { $set: updatedData });
        console.log('Customer updated:', result.modifiedCount);
    } finally {
        // await client.close();
    }
}

async function deleteCustomer(customerId) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const customersCollection = db.collection('Customers');
        const result = await customersCollection.deleteOne({ _id: ObjectId(customerId) });
        console.log('Customer deleted:', result.deletedCount);
    } finally {
        // await client.close();
    }
}

async function getAllCustomers() {
    try {
        await client.connect();
        const db = client.db(dbName);
        const customersCollection = db.collection('Customers');
        const customers = await customersCollection.find({}).toArray();
        console.log('All customers:', customers);
        return customers;
    } finally {
        // await client.close();
    }
}

// Function to read an admin by username from the database
async function readAdminByUsername(username) {
    try {
        await client.connect();
        const db = client.db(dbName);
        const adminsCollection = db.collection('Admins');
        const admin = await adminsCollection.findOne({ username });
        return admin;
    } finally {
        // await client.close();
    }
}

// Middleware to verify JWT token
function verifyToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
        console.log('No token provided');
        return res.status(403).json({ error: 'No token provided' });
    }
console.log(authHeader);
    const token = authHeader.split(' ')[1];
    if (!token) {
        console.log('Token not found after splitting');
        return res.status(403).json({ error: 'Token not found' });
    }

    jwt.verify(token, JWT_SECRET, (err, decoded) => {
        if (err) {
            console.log('Token verification failed:', err);
            
            return res.status(401).json({ error: 'Failed to authenticate token' });
        }
        req.user = decoded;
        next();
    });
}

// Login endpoint
app.post('/login', async (req, res, next) => {
    try {
        const { username, password } = req.body;
        const admin = await readAdminByUsername(username);

        if (admin && admin.password === password) {
            const token = jwt.sign({ username: admin.username }, JWT_SECRET, { expiresIn: '1h' });
            res.json({ token });
        } else {
            res.status(401).json({ error: 'Invalid credentials' });
        }
    } catch (error) {
        console.error('Error logging in:', error);
        next(error);
    }
});

// Register endpoint
app.post('/register', async (req, res, next) => {
    try {
        const { username, password } = req.body;
        const existingAdmin = await readAdminByUsername(username);
        if (existingAdmin) {
            return res.status(400).json({ error: 'Admin already exists' });
        }

        const adminData = { username, password };
        await createAdmin(adminData);
        res.status(201).json({ message: 'Admin registered successfully' });
    } catch (error) {
        console.error('Error registering admin:', error);
        next(error);
    }
});

// Define routes to return the list of products and customers
app.get('/Products', verifyToken, async (req, res, next) => {
    try {
        const products = await getAllProducts();
        res.json(products);
    } catch (error) {
        console.error("Error fetching products:", error);
        next(error);
    }
});

// Create a product
app.post('/Products', verifyToken, async (req, res, next) => {
    try {
        const productData = req.body;
        await createProduct(productData);
        res.status(201).send("Product created successfully");
    } catch (error) {
        console.error("Error creating product:", error);
        next(error);
    }
});

// Read a product by ID
app.get('/Products/:id', verifyToken, async (req, res, next) => {
    try {
        const productId = req.params.id;
        const product = await readProductById(productId);
        if (!product) {
            return res.status(404).send("Product not found");
        }
        res.json(product);
    } catch (error) {
        console.error("Error reading product:", error);
        next(error);
    }
});

// Update a product by ID
app.put('/Products/:id', verifyToken, async (req, res, next) => {
    try {
        const productId = req.params.id;
        const updatedData = req.body;
        await updateProduct(productId, updatedData);
        res.send("Product updated successfully");
    } catch (error) {
        console.error("Error updating product:", error);
        next(error);
    }
});

// Delete a product by ID
app.delete('/Products/:id', verifyToken, async (req, res, next) => {
    try {
        const productId = req.params.id;
        await deleteProduct(productId);
        res.send("Product deleted successfully");
    } catch (error) {
        console.error("Error deleting product:", error);
        next(error);
    }
});

// Define routes for customers
app.get('/Customers', verifyToken, async (req, res, next) => {
    try {
        const customers = await getAllCustomers();
        res.json(customers);
    } catch (error) {
        console.error("Error fetching customers:", error);
        next(error);
    }
});

// Create a customer
app.post('/Customers', verifyToken, async (req, res, next) => {
    try {
        const customerData = req.body;
        await createCustomer(customerData);
        res.status(201).send("Customer created successfully");
    } catch (error) {
        console.error("Error creating customer:", error);
        next(error);
    }
});

// Read a customer by ID
app.get('/Customers/:id', verifyToken, async (req, res, next) => {
    try {
        const customerId = req.params.id;
        const customer = await readCustomerById(customerId);
        if (!customer) {
            return res.status(404).send("Customer not found");
        }
        res.json(customer);
    } catch (error) {
        console.error("Error reading customer:", error);
        next(error);
    }
});

// Update a customer by ID
app.put('/Customers/:id', verifyToken, async (req, res, next) => {
    try {
        const customerId = req.params.id;
        const updatedData = req.body;
        await updateCustomer(customerId, updatedData);
        res.send("Customer updated successfully");
    } catch (error) {
        console.error("Error updating customer:", error);
        next(error);
    }
});

// Delete a customer by ID
app.delete('/Customers/:id', verifyToken, async (req, res, next) => {
    try {
        const customerId = req.params.id;
        await deleteCustomer(customerId);
        res.send("Customer deleted successfully");
    } catch (error) {
        console.error("Error deleting customer:", error);
        next(error);
    }
});

// Define routes for admins
app.get('/Admins', verifyToken, async (req, res, next) => {
    try {
        const admins = await getAllAdmins();
        res.json(admins);
    } catch (error) {
        console.error("Error fetching admins:", error);
        next(error);
    }
});

// Create an admin
app.post('/Admins', verifyToken, async (req, res, next) => {
    try {
        const adminData = req.body;
        await createAdmin(adminData);
        res.status(201).send("Admin created successfully");
    } catch (error) {
        console.error("Error creating admin:", error);
        next(error);
    }
});

// Read an admin by ID
app.get('/Admins/:id', verifyToken, async (req, res, next) => {
    try {
        const adminId = req.params.id;
        const admin = await readAdminById(adminId);
        if (!admin) {
            return res.status(404).send("Admin not found");
        }
        res.json(admin);
    } catch (error) {
        console.error("Error reading admin:", error);
        next(error);
    }
});

// Update an admin by ID
app.put('/Admins/:id', verifyToken, async (req, res, next) => {
    try {
        const adminId = req.params.id;
        const updatedData = req.body;
        await updateAdmin(adminId, updatedData);
        res.send("Admin updated successfully");
    } catch (error) {
        console.error("Error updating admin:", error);
        next(error);
    }
});

// Delete an admin by ID
app.delete('/Admins/:id', verifyToken, async (req, res, next) => {
    try {
        const adminId = req.params.id;
        await deleteAdmin(adminId);
        res.send("Admin deleted successfully");
    } catch (error) {
        console.error("Error deleting admin:", error);
        next(error);
    }
});

// Serve static pages
app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/contact', (req, res) => {
    res.render('contact');
});

app.get('/', (req, res) => {
    res.render('index');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/register', (req, res) => {
    res.render('register');
});

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'reactapi/build')));

// The "catchall" handler: for any request that doesn't match one of the above, send back React's index.html file.
app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'reactapi', 'build', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Internal Server Error' });
});

async function run() {
    try {
        await client.connect();
        console.log("Connected to MongoDB successfully!");

        // Start the server after all routes are defined
        const server = app.listen(port, () => {
            console.log(`Server is running on port ${port}`);
        });

        // Close MongoDB client connection when the server is closed
        server.on('close', async () => {
            console.log("Closing MongoDB connection...");
            await client.close();
            console.log("MongoDB connection closed.");
        });
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);
    }
}

run().catch(console.dir);
