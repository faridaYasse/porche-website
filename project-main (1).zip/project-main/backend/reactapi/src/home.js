// Home.js
import React from 'react';
import SideMenu from './SideMenu'; // Import the SideMenu component
import './home.css'; // Import the Home CSS

const Home = ({ isOpen, toggleMenu, handleLogout, isLoggedIn }) => {
    return (
        <div className={`home-container ${isOpen ? 'menu-open' : ''}`}>
            <SideMenu isOpen={isOpen} toggleMenu={toggleMenu} handleLogout={handleLogout} isLoggedIn={isLoggedIn} />
            <div className="content">
                <h2>Welcome to Porsche</h2>
                <p>This is the home page for logged-in users.</p>
            </div>
        </div>
    );
};

export default Home;
