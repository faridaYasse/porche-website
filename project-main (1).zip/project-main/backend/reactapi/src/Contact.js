// contact.js
import React from 'react';
import './Contact.css'; // Import CSS for Contact page

const Contact = () => {
    return (
        <div className="m-1">
            <h1>Contact Us</h1>
            <div className="fs-6 fw-light mb-2">Post your message below. We will get back to you ASAP</div>
            <form id="contact_form" name="contact_form" method="post">
                <div className="mb-5">
                    <label htmlFor="message">Message</label>
                    <textarea className="form-control" id="message" name="message" rows="5"></textarea>
                </div>
                <div className="mb-5 row">
                    <div className="col">
                        <label>Your Name:</label>
                        <input type="text" required maxLength="50" className="form-control" id="name" name="name" />
                    </div>
                    <div className="col">
                        <label htmlFor="email_addr">Your Email:</label>
                        <input type="email" required maxLength="50" className="form-control" id="email_addr" name="email" placeholder="name@example.com" />
                    </div>
                </div>
                <div className="d-grid">
                    <button type="submit" className="btn btn-success">Post</button>
                </div>
            </form>
        </div>
    );
};

export default Contact;
